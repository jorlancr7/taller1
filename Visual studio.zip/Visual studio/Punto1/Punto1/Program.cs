﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            
                double precio_jeans = 650.00; 
                double descuento = 0.30; 

                Console.WriteLine("Ingrese la cantidad de jeans que desea comprar:");
                int num_jeans = int.Parse(Console.ReadLine()); 

                if (num_jeans <= 0)
                { 
                    Console.WriteLine("Debe comprar almenos un pantalon para que se valide la compra..");
                    return;
                }

                double total = num_jeans * precio_jeans; 

                if (num_jeans > 2)
                { 
                    total *=  (1 - descuento);
                }
            
            Console.WriteLine($"El total a pagar es: ${total.ToString("0.00")}\n");
            Console.WriteLine("Gracias por su compra tenga buen dia :)");

            Console.ReadKey();
            }
        }

    }


