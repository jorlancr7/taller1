﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int personas;
            double promedioAlturas;
            Console.Write("Ingrese la cantidad de personas: ");
             personas = Convert.ToInt32(Console.ReadLine());

            double[] alturas = new double[personas];
            double total_Alturas = 0;

            for (int i = 0; i < personas; i++)
            {
                Console.Write("Ingrese la altura de la persona {0}: ", i + 1);
                alturas[i] = Convert.ToDouble(Console.ReadLine());
                total_Alturas += alturas[i];
            }

             promedioAlturas = total_Alturas / personas;
            Console.WriteLine("Altura promedio de las personas: {0}", promedioAlturas);
            Console.ReadKey();

        }
    }
}
