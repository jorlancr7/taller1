﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int[] numeros = new int[100];
            for (int i = 0; i < 100; i++)
            {
                numeros[i] = rnd.Next(1, 11); 
            }

            int Cont_num1 = 0, cont_num5 = 0, cont_num10 = 0, contadorOtros = 0;
            for (int i = 0; i < 100; i++)
            {
                if (numeros[i] == 1)
                {
                    Cont_num1++;
                }
                else if (numeros[i] == 5)
                {
                    cont_num5++;
                }
                else if (numeros[i] == 10)
                {
                    cont_num10++;
                }
                else
                {
                    contadorOtros++;
                }
            }

            Console.WriteLine("\nSe generaron {0} numeros iguales a 1", Cont_num1);
            Console.WriteLine("\nSe generaron {0} numeros iguales a 5", cont_num5);
            Console.WriteLine("\nSe generaron {0} numeros iguales a 10", cont_num10);
            Console.WriteLine("\nSe generaron {0} numeros que no son ni 1, 5 ni 10", contadorOtros);
            Console.ReadKey();
        }
    }
}
