﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int edad;
            Console.WriteLine("Dijite la edad del usuario:");
            edad = Convert.ToInt32(Console.ReadLine());

            if (edad > 0 && edad<= 2) {

                Console.WriteLine("el usurio es un bebe");
            }
            else if (edad > 2 && edad <= 12)
            {

                Console.WriteLine("el usuario es un niño");
            }
            else if (edad > 12 && edad <= 18)
            {

                Console.WriteLine("el usuario es un adolecente");
            }
            else if (edad > 18 && edad <= 30)
            {
                Console.WriteLine("el usuario es un adulto joven");
            }
            else if (edad > 30 && edad <= 65)
            {
                Console.WriteLine("el usuario es un adulto");
            }
            else { Console.WriteLine("el usuario es un anciano de la tercera edad"); }

            Console.ReadLine();
        }
    }
}
