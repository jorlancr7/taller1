﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numeroCuenta;
            double saldo;
            double Acreedores = 0;

            do
            {
                Console.Write("Ingrese el número de cuenta (negativo para terminar): ");
                numeroCuenta =Convert.ToInt32(Console.ReadLine());

                if (numeroCuenta >= 0)
                {
                    Console.Write("Ingrese el saldo actual de la cuenta: ");
                    saldo = Convert.ToDouble(Console.ReadLine());

                    Console.Write("Cuenta {0}: ", numeroCuenta);

                    if (saldo > 0)
                    {
                        Console.WriteLine("Acreedor");
                        Acreedores += saldo;
                    }
                    else if (saldo < 0)
                    {
                        Console.WriteLine("Deudor");
                    }
                    else
                    {
                        Console.WriteLine("Nulo");
                    }
                }

            } while (numeroCuenta >= 0);

            Console.WriteLine("\nSuma total de saldos acreedores: {0}", Acreedores);
            Console.ReadKey();

        }
    }
}
