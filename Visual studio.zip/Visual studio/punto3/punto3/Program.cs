﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double num1;
            double num2;
            int operacion;

            Console.WriteLine("Dijite el primer numero:");
            num1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Dijite el segundo numero:");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese la operacion que desee realizar \n1. suma \n2. resta \n3. multiplicacion \n4. division.");
            operacion = Convert.ToInt32(Console.ReadLine());

            double resultado = 0; 

            switch (operacion)
            { 
                case 1:
                    resultado = num1 + num2;
                    break;
                case 2: 
                    resultado = num1 - num2;
                    break;
                case 3: 
                    resultado = num1 * num2;
                    break;
                case 4: 
                    if (num2 == 0)
                    { 
                        Console.WriteLine("No se puede dividir entre cero.");
                        return;
                    }
                    resultado = num1 / num2;
                    break;
                default: 
                    Console.WriteLine("La operación ingresada no es válida.");
                    return;
            }

            Console.WriteLine($"El resultado de la operación es: {resultado}");
            Console.ReadKey();
        }
    }
}
