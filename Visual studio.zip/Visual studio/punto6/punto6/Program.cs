﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] dias = { "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo" };

            int diasLaborables = 0, diasFinDeSemana = 0;

            for (int i = 0; i < dias.Length; i++)
            {
                if (dias[i] == "Lunes" || dias[i] == "Martes" || dias[i] == "Miércoles" || dias[i] == "Jueves" || dias[i] == "Viernes")
                {
                    diasLaborables++;
                }
                else
                {
                    diasFinDeSemana++;
                }
            }

            Console.WriteLine("Cantidad de días laborables es: {0}", diasLaborables);
            Console.WriteLine("Cantidad de días de fin de semana es: {0}", diasFinDeSemana);
            Console.ReadKey();
        }
    }
}
