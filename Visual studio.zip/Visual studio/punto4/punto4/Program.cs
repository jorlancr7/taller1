﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x;
            Console.WriteLine("Ingrese el valor de x:");
            x = Convert.ToDouble(Console.ReadLine()); 

            double resultado = 0; 

            if (x <= 0)
            { 
                resultado = 0;
            }
            else
            { 
                resultado = Math.Pow(x, 2);
            }

            Console.WriteLine($"El valor de la función en x={x} es: {resultado}");

            Console.ReadKey();
            }
        }

    }
