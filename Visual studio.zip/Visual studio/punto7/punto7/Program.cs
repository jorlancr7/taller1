﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int notas1 = 0;
            int notas2 = 0;
            double notas_estudiante;

            for (int i = 1; i <= 10; i++)
            {
                Console.Write("Ingrese la nota del alumno {0}: ", i);
                notas_estudiante = Convert.ToDouble(Console.ReadLine());

                if (notas_estudiante >= 7)
                {
                    notas1++;
                }
                else
                {
                    notas2++;
                }
            }

            Console.WriteLine("La cantidad de alumnos con nota mayor o igual a 7: {0}", notas1);
            Console.WriteLine("La cantidad de alumnos con nota menor a 7: {0}", notas2);
            Console.ReadKey();
        }
    }
}
