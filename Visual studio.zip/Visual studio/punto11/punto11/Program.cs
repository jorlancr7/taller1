﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int Numeros;
            Console.Write("Ingrese la cantidad de números a procesar: ");
             Numeros = Convert.ToInt32(Console.ReadLine());

            int num_Pares = 0;
            int num_Impares = 0;

            int i = 0;
            while (i < Numeros)
            {
                Console.Write("Ingrese un número entero: ");
                int numero = int.Parse(Console.ReadLine());

                if (numero % 2 == 0)
                {
                    num_Pares++;
                }
                else
                {
                    num_Impares++;
                }

                i++;
            }

            Console.WriteLine("\nCantidad de números pares: {0}", num_Pares);
            Console.WriteLine("\nCantidad de números impares: {0}", num_Impares);
            Console.ReadKey();
        }
    }
}
