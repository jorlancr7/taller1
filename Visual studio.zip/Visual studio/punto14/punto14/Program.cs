﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto14
{
    internal class Program
    {
        static void Main(string[] args)
        {
        
                Console.Write("Ingrese el tamaño del vector: ");
                int n = Convert.ToInt32(Console.ReadLine());

                int[] vector = new int[n];

                for (int i = 0; i < n; i++)
                {
                    Console.Write($"Ingrese el elemento {i + 1}: ");
                    vector[i] = Convert.ToInt32(Console.ReadLine());
                }

                int menor = vector[0];
                bool repetido = false;

                for (int i = 1; i < n; i++)
                {
                    if (vector[i] < menor)
                    {
                        menor = vector[i];
                    }
                }

                Console.WriteLine($"El menor elemento es: {menor}");

                for (int i = 0; i < n; i++)
                {
                    if (vector[i] == menor && !repetido)
                    {
                        repetido = true;
                    }
                    else if (vector[i] == menor && repetido)
                    {
                        Console.WriteLine($"El elemento {menor} está repetido en el vector.");
                        break;
                    
                }
                }
            Console.ReadKey();
        }
        }

    }

