﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero_puntos;
            Console.Write("Ingrese la cantidad de puntos a procesar: ");
          numero_puntos = Convert.ToInt32(Console.ReadLine());

            int Cuadrante1 = 0;
            int Cuadrante2 = 0;
            int Cuadrante3 = 0;
            int Cuadrante4 = 0;

            for (int i = 0; i < numero_puntos; i++)
            {
                Console.Write("Ingrese la coordenada x del punto {0}: ", i + 1);
                double x = Convert.ToDouble(Console.ReadLine());

                Console.Write("Ingrese la coordenada y del punto {0}: ", i + 1);
                double y = Convert.ToDouble(Console.ReadLine());

                if (x > 0 && y > 0)
                {
                    Cuadrante1 ++;
                }
                else if (x < 0 && y > 0)
                {
                    Cuadrante2 ++;
                }
                else if (x < 0 && y < 0)
                {
                    Cuadrante3 ++;
                }
                else if (x > 0 && y < 0)
                {
                    Cuadrante4 ++;
                }
            }

            Console.WriteLine("Cantidad de puntos en el primer cuadrante: {0}", Cuadrante1);
            Console.WriteLine("Cantidad de puntos en el segundo cuadrante: {0}", Cuadrante2);
            Console.WriteLine("Cantidad de puntos en el tercer cuadrante: {0}", Cuadrante3);
            Console.WriteLine("Cantidad de puntos en el cuarto cuadrante: {0}", Cuadrante4);
            Console.ReadKey();
        }
    }
}
