﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x, y;
            Console.Write("\nIngrese la coordenada para x: ");
            x = Convert.ToDouble(Console.ReadLine());

            Console.Write("\nIngrese la coordenada para y: ");
            y = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Los puntos en el plano son ({0}, {1})", x, y);
            Console.ReadKey();
        }
    }
}
